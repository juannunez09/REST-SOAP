/**
 * SOAPExampleClient_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.example.www.SOAPExampleClient;

public interface SOAPExampleClient_Service extends javax.xml.rpc.Service {
    public java.lang.String getSOAPExampleClientSOAPAddress();

    public org.example.www.SOAPExampleClient.SOAPExampleClient_PortType getSOAPExampleClientSOAP() throws javax.xml.rpc.ServiceException;

    public org.example.www.SOAPExampleClient.SOAPExampleClient_PortType getSOAPExampleClientSOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
