package org.example.www.SOAPExampleClient;

public class SOAPExampleClientProxy implements org.example.www.SOAPExampleClient.SOAPExampleClient_PortType {
  private String _endpoint = null;
  private org.example.www.SOAPExampleClient.SOAPExampleClient_PortType sOAPExampleClient_PortType = null;
  
  public SOAPExampleClientProxy() {
    _initSOAPExampleClientProxy();
  }
  
  public SOAPExampleClientProxy(String endpoint) {
    _endpoint = endpoint;
    _initSOAPExampleClientProxy();
  }
  
  private void _initSOAPExampleClientProxy() {
    try {
      sOAPExampleClient_PortType = (new org.example.www.SOAPExampleClient.SOAPExampleClient_ServiceLocator()).getSOAPExampleClientSOAP();
      if (sOAPExampleClient_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sOAPExampleClient_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sOAPExampleClient_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sOAPExampleClient_PortType != null)
      ((javax.xml.rpc.Stub)sOAPExampleClient_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.example.www.SOAPExampleClient.SOAPExampleClient_PortType getSOAPExampleClient_PortType() {
    if (sOAPExampleClient_PortType == null)
      _initSOAPExampleClientProxy();
    return sOAPExampleClient_PortType;
  }
  
  public java.lang.String newOperation(java.lang.String in) throws java.rmi.RemoteException{
    if (sOAPExampleClient_PortType == null)
      _initSOAPExampleClientProxy();
    return sOAPExampleClient_PortType.newOperation(in);
  }
  
  
}